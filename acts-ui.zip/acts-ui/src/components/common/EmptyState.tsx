export default function EmptyState({label}:{label:string}){
return (
<div className="p-10 border rounded-xl text-center text-muted-foreground">{label}</div>
)
}