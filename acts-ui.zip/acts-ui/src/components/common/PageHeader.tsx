export default function PageHeader({ title }: { title: string }) {
  return (
    <div className="mb-4">
      <h1 className="text-2xl font-extrabold text-ink">{title}</h1>
    </div>
  )
}
