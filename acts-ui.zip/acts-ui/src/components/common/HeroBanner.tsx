interface HeroBannerProps {
  title: string
  subtitle?: string
  bgImage?: string
}

export default function HeroBanner({ title, subtitle, bgImage }: HeroBannerProps) {
  return (
    <section
      className="relative rounded-2xl shadow-card overflow-hidden bg-white mb-6"
      style={{
        backgroundImage: bgImage ? `url(${bgImage})` : undefined,
        backgroundSize: "cover",
        backgroundPosition: "center"
      }}
    >
      <div className="p-8 bg-white/80 backdrop-blur-sm">
        <h1 className="text-3xl font-extrabold text-ink">{title}</h1>
        {subtitle && (
          <p className="text-base text-slate-700 mt-1">{subtitle}</p>
        )}
      </div>
    </section>
  )
}
