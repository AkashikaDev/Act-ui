import { Avatar, AvatarFallback } from '@/components/ui/avatar'

export default function Topbar(){
return (
<header className="h-14 border-b flex items-center justify-between px-4">
<div className="md:hidden font-semibold">ACTS</div>
<div className="text-sm text-muted-foreground">AI‑Powered Action Tracking</div>
<div className="flex items-center gap-3">
<span className="text-sm text-muted-foreground">You: Host</span>
<Avatar className="h-7 w-7"><AvatarFallback>Y</AvatarFallback></Avatar>
</div>
</header>
)
}