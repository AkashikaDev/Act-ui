import { NavLink } from 'react-router-dom'
import { CalendarCheck2, CheckSquare, ClipboardList, MessagesSquare, FileText } from 'lucide-react'

export default function Sidebar(){
const nav = [
{ to: '/', label: 'AI Summary', icon: FileText },
{ to: '/review', label: 'Host Review', icon: ClipboardList },
{ to: '/assign', label: 'Participant Actions', icon: CheckSquare },
{ to: '/tasks', label: 'Task Tracking', icon: CalendarCheck2 },
{ to: '/followups', label: 'Follow‑Ups', icon: MessagesSquare },
]
return (
<aside className="hidden md:block h-screen w-[var(--sidebar-w)] border-r bg-background/60 backdrop-blur">
<div className="p-4 text-xl font-semibold">ACTS</div>
<nav className="px-2 space-y-1">
{nav.map(({to,label,icon:Icon}) => (
<NavLink key={to} to={to} className={({isActive}) =>
`flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-muted ${isActive? 'bg-muted font-medium':''}`
}>
<Icon size={18}/><span>{label}</span>
</NavLink>
))}
</nav>
</aside>
)
}