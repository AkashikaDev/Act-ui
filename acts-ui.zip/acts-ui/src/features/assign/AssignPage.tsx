import HeroBanner from "@/components/common/HeroBanner"
import hero from "@/assets/hero-bg.svg"
import { useActsStore } from "@/store/useActsStore"
import { useEffect, useMemo, useState } from "react"
import { fmtDate } from "@/lib/format"

export default function AssignPage() {
  const { actions, users, loadAll, setAction } = useActsStore()
  useEffect(() => { loadAll() }, [])

  const me = users[2] || { id: "u3", name: "Jordan Ops" }

  const myItems = useMemo(
    () => actions.filter(a => a.ownerId === me.id),
    [actions, me.id]
  )

  const [due, setDue] = useState("")

  async function updateDue(id: string) {
    const a = actions.find(x => x.id === id)!
    await setAction({
      ...a,
      dueDate: due ? new Date(due).toISOString() : a.dueDate
    })
  }

  return (
    <div className="space-y-6">
      <HeroBanner
        title="Participant Action Panel"
        subtitle="View and manage your assigned tasks"
        bgImage={hero}
      />

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
        {myItems.map(a => (
          <div key={a.id} className="bg-white border rounded-2xl shadow p-4 space-y-2">
            <div className="font-medium">{a.title}</div>
            <div className="text-sm text-slate-600">Due: {fmtDate(a.dueDate)}</div>
            <div className="flex items-center gap-2 pt-1">
              <input
                type="date"
                value={due}
                onChange={e => setDue(e.target.value)}
                className="h-9 border rounded-lg px-3"
              />
              <button
                className="px-3 py-1.5 bg-brand text-white rounded-lg"
                onClick={() => updateDue(a.id)}
              >
                Update
              </button>
            </div>
          </div>
        ))}
        {!myItems.length && (
          <div className="text-sm text-slate-600">No assignments right now 🎉</div>
        )}
      </div>
    </div>
  )
}
