import HeroBanner from "@/components/common/HeroBanner"
import hero from "@/assets/hero-bg.svg"
import { useActsStore } from "@/store/useActsStore"
import { useEffect, useMemo } from "react"
import {
  PieChart, Pie, Cell, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis
} from "recharts"

export default function DashboardPage() {
  const { actions, loadAll } = useActsStore()
  useEffect(() => { loadAll() }, [])

  const stats = useMemo(() => {
    const total = actions.length
    const accepted = actions.filter(a => a.status === "accepted").length
    const pending = actions.filter(a => a.status === "pending").length
    const rejected = actions.filter(a => a.status === "rejected").length
    const pct = total ? Math.round((accepted / total) * 100) : 0
    return { total, accepted, pending, rejected, pct }
  }, [actions])

  const radialData = [
    { name: "Accepted", value: stats.accepted },
    { name: "Remaining", value: stats.total - stats.accepted }
  ]
  const breakdown = [
    { status: "Accepted", value: stats.accepted },
    { status: "Pending", value: stats.pending },
    { status: "Rejected", value: stats.rejected }
  ]

  return (
    <div className="space-y-6">
      <HeroBanner
        title="My Dashboard"
        subtitle="Your consolidated view of tasks, notifications, and progress"
        bgImage={hero}
      />

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Action Items */}
        <div className="bg-white rounded-2xl shadow p-4">
          <h2 className="font-semibold mb-2">Action Items</h2>
          <ul className="space-y-2">
            {actions.map(a => (
              <li key={a.id} className="flex justify-between border p-2 rounded">
                <span>{a.title}</span>
                <span className="text-xs px-2 py-1 rounded bg-slate-100">{a.status}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Notifications */}
        <div className="bg-white rounded-2xl shadow p-4">
          <h2 className="font-semibold mb-2">Notifications</h2>
          <p className="text-sm text-slate-600">3 reminders pending review.</p>
        </div>

        {/* My Tasks */}
        <div className="bg-white rounded-2xl shadow p-4">
          <h2 className="font-semibold mb-2">My Tasks</h2>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={breakdown}>
              <XAxis dataKey="status" />
              <YAxis allowDecimals={false} />
              <Bar dataKey="value" fill="#146EF5" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Progress */}
        <div className="bg-white rounded-2xl shadow p-4 text-center">
          <h2 className="font-semibold mb-2">Progress</h2>
          <ResponsiveContainer width={200} height={200}>
            <PieChart>
              <Pie data={radialData} dataKey="value" innerRadius={60} outerRadius={80}>
                <Cell fill="#146EF5" />
                <Cell fill="#E2E8F0" />
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <p className="mt-2 text-sm text-slate-600">
            {stats.pct}% completion out of {stats.total} tasks
          </p>
        </div>
      </div>
    </div>
  )
}
