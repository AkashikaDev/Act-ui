import HeroBanner from "@/components/common/HeroBanner"
import hero from "@/assets/hero-bg.svg"
import { useActsStore } from "@/store/useActsStore"
import { useEffect, useMemo } from "react"
import {
  PieChart, Pie, Cell, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, Tooltip
} from "recharts"

export default function TasksPage() {
  const { actions, loadAll } = useActsStore()
  useEffect(() => { loadAll() }, [])

  const stats = useMemo(() => {
    const total = actions.length
    const accepted = actions.filter(a => a.status === "accepted").length
    const pending = actions.filter(a => a.status === "pending").length
    const rejected = actions.filter(a => a.status === "rejected").length
    const done = actions.filter(a => a.status === "done").length
    const pct = total ? Math.round((accepted / total) * 100) : 0
    return { total, accepted, pending, rejected, done, pct }
  }, [actions])

  const pieData = [
    { name: "Accepted", value: stats.accepted },
    { name: "Pending", value: stats.pending },
    { name: "Rejected", value: stats.rejected },
    { name: "Done", value: stats.done }
  ]
  const COLORS = ["#146EF5", "#FACC15", "#EF4444", "#10B981"]

  const barData = [
    { name: "Tasks", Accepted: stats.accepted, Pending: stats.pending, Rejected: stats.rejected, Done: stats.done }
  ]

  return (
    <div className="space-y-6">
      <HeroBanner
        title="Task Tracking Dashboard"
        subtitle="Monitor team productivity and task completion"
        bgImage={hero}
      />

      {/* Completion Ring */}
      <div className="bg-white p-6 rounded-2xl shadow text-center">
        <ResponsiveContainer width={200} height={200}>
          <PieChart>
            <Pie data={pieData} dataKey="value" innerRadius={50} outerRadius={80}>
              {pieData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <p className="mt-2 text-sm text-slate-600">
          {stats.accepted}/{stats.total} accepted
        </p>
      </div>

      {/* Productivity Breakdown */}
      <div className="bg-white p-6 rounded-2xl shadow">
        <h2 className="font-semibold text-slate-800 mb-3">Productivity Breakdown</h2>
        <ResponsiveContainer width="100%" height={250}>
          <BarChart data={barData}>
            <XAxis dataKey="name" />
            <YAxis allowDecimals={false} />
            <Tooltip />
            <Bar dataKey="Accepted" stackId="a" fill="#146EF5" />
            <Bar dataKey="Pending" stackId="a" fill="#FACC15" />
            <Bar dataKey="Rejected" stackId="a" fill="#EF4444" />
            <Bar dataKey="Done" stackId="a" fill="#10B981" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Task list */}
      <div className="bg-white p-6 rounded-2xl shadow">
        <h2 className="font-semibold text-slate-800 mb-3">Task List</h2>
        <ul className="space-y-2">
          {actions.map(a => (
            <li key={a.id} className="flex justify-between items-center border p-3 rounded-lg">
              <span>{a.title}</span>
              <span className="text-xs px-2 py-1 rounded bg-slate-100">{a.status}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
