import HeroBanner from "@/components/common/HeroBanner"
import hero from "@/assets/hero-bg.svg"
import { useState } from "react"

export default function FollowupsPage() {
  const [msg, setMsg] = useState("Reminder: please update your task status today.")
  const [sent, setSent] = useState<{id:string;message:string}[]>([])

  function send() {
    setSent([{ id: Math.random().toString(36).slice(2,8), message: msg }, ...sent])
  }

  return (
    <div className="space-y-6">
      <HeroBanner
        title="Follow-Up Nudges"
        subtitle="Send reminders and track follow-up actions"
        bgImage={hero}
      />

      <div className="grid lg:grid-cols-2 gap-4">
        <div className="bg-white border rounded-2xl shadow p-4 space-y-3">
          <div className="font-medium">Compose nudge</div>
          <input className="border rounded-lg px-3 py-2 w-full" value={msg} onChange={e=>setMsg(e.target.value)} />
          <button className="px-3 py-2 bg-brand text-white rounded-lg" onClick={send}>Send (simulate)</button>
        </div>
        <div className="bg-white border rounded-2xl shadow p-4">
          <div className="font-medium mb-2">Recent nudges</div>
          <div className="space-y-2">
            {sent.map(n => <div key={n.id} className="border rounded-lg p-3 text-sm bg-white">{n.message}</div>)}
            {!sent.length && <div className="text-sm text-slate-600">No nudges sent yet.</div>}
          </div>
        </div>
      </div>
    </div>
  )
}
