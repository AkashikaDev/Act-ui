import HeroBanner from "@/components/common/HeroBanner"
import hero from "@/assets/hero-bg.svg"
import { useActsStore } from "@/store/useActsStore"
import { useEffect, useState, useMemo } from "react"
import { fmtDate } from "@/lib/format"
import { toast } from "sonner"
import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts"

export default function ReviewPage() {
  const { actions, users, loadAll, addAction, setAction, deleteAction } = useActsStore()
  useEffect(() => { loadAll() }, [])

  // New Task form
  const [newTitle, setNewTitle] = useState("")
  const [newOwner, setNewOwner] = useState("")
  const [newDue, setNewDue] = useState("")

  // Editing state
  const [editing, setEditing] = useState<string>()
  const [editTitle, setEditTitle] = useState("")
  const [editOwner, setEditOwner] = useState("")
  const [editDue, setEditDue] = useState("")

  // Stats
  const stats = useMemo(() => {
    const total = actions.length
    const accepted = actions.filter(a => a.status === "accepted").length
    const pending = actions.filter(a => a.status === "pending").length
    const rejected = actions.filter(a => a.status === "rejected").length
    const pct = total ? Math.round((accepted / total) * 100) : 0
    return { total, accepted, pending, rejected, pct }
  }, [actions])

  const chartData = [
    { name: "Accepted", value: stats.accepted },
    { name: "Remaining", value: stats.total - stats.accepted }
  ]
  const COLORS = ["#146EF5", "#E2E8F0"]

  // --- Actions ---
  async function handleAddTask() {
    if (!newTitle) {
      toast.error("Task title required")
      return
    }
    const newTask = {
      id: "a" + Math.random().toString(36).slice(2),
      title: newTitle,
      type: "Action" as const,
      ownerId: newOwner || undefined,
      ownerName: users.find(u => u.id === newOwner)?.name,
      status: "pending" as const,
      dueDate: newDue ? new Date(newDue).toISOString() : undefined
    }
    await addAction(newTask)
    setNewTitle("")
    setNewOwner("")
    setNewDue("")
    toast.success("Task added")
  }

  function startEdit(id: string) {
    const a = actions.find(x => x.id === id)!
    setEditing(id)
    setEditTitle(a.title)
    setEditOwner(a.ownerId || "")
    setEditDue((a.dueDate || "").slice(0, 10))
  }

  async function saveEdit() {
    const a = actions.find(x => x.id === editing!)!
    await setAction({
      ...a,
      title: editTitle,
      ownerId: editOwner || undefined,
      ownerName: users.find(u => u.id === editOwner)?.name,
      dueDate: editDue ? new Date(editDue).toISOString() : undefined
    })
    setEditing(undefined)
    toast.success("Task updated")
  }

  async function approve(id: string) {
    const a = actions.find(x => x.id === id)!
    await setAction({ ...a, status: "accepted" })
    toast.success("Task approved")
  }

  async function reject(id: string) {
    const a = actions.find(x => x.id === id)!
    await setAction({ ...a, status: "rejected" })
    toast.error("Task rejected")
  }

  async function handleDelete(id: string) {
    await deleteAction(id)
    toast.success("Task deleted")
  }

  // Filters
  const pendingItems = actions.filter(a => a.status === "pending")
  const historyItems = actions.filter(a => a.status === "accepted" || a.status === "rejected")

  return (
    <div className="space-y-6">
      <HeroBanner
        title="Host Review & Edit"
        subtitle="Approve, reject, amend, delete, or add new action items"
        bgImage={hero}
      />

      {/* Chart Stats */}
      <div className="bg-white rounded-2xl shadow p-6 flex flex-col items-center">
        <ResponsiveContainer width={200} height={200}>
          <PieChart>
            <Pie data={chartData} innerRadius={60} outerRadius={80} paddingAngle={3} dataKey="value">
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <p className="mt-3 text-sm text-slate-600">
          Accepted {stats.accepted} / {stats.total} ({stats.pct}%)
        </p>
      </div>

      {/* Add Task */}
      <div className="bg-white rounded-2xl shadow p-4 space-y-3">
        <h2 className="font-semibold">Add New Task</h2>
        <input
          className="border rounded-lg w-full px-3 py-2"
          placeholder="Task title"
          value={newTitle}
          onChange={e => setNewTitle(e.target.value)}
        />
        <select
          className="border rounded-lg w-full px-3 py-2"
          value={newOwner}
          onChange={e => setNewOwner(e.target.value)}
        >
          <option value="">Select owner</option>
          {users.map(u => (
            <option key={u.id} value={u.id}>{u.name}</option>
          ))}
        </select>
        <input
          type="date"
          className="border rounded-lg w-full px-3 py-2"
          value={newDue}
          onChange={e => setNewDue(e.target.value)}
        />
        <button className="px-3 py-2 bg-brand text-white rounded-lg" onClick={handleAddTask}>
          Add Task
        </button>
      </div>

      {/* Pending List */}
      <h2 className="font-semibold text-slate-800">Pending Actions</h2>
      <div className="grid lg:grid-cols-2 gap-4">
        {pendingItems.map(a => (
          <div key={a.id} className="bg-white border rounded-2xl shadow p-4 space-y-3">
            {editing === a.id ? (
              <div className="space-y-2">
                <input
                  className="border rounded-lg w-full px-3 py-2"
                  value={editTitle}
                  onChange={e => setEditTitle(e.target.value)}
                />
                <select
                  className="border rounded-lg w-full px-3 py-2"
                  value={editOwner}
                  onChange={e => setEditOwner(e.target.value)}
                >
                  <option value="">Select owner</option>
                  {users.map(u => (
                    <option key={u.id} value={u.id}>{u.name}</option>
                  ))}
                </select>
                <input
                  type="date"
                  className="border rounded-lg w-full px-3 py-2"
                  value={editDue}
                  onChange={e => setEditDue(e.target.value)}
                />
                <div className="flex gap-2">
                  <button className="px-3 py-2 bg-brand text-white rounded-lg" onClick={saveEdit}>
                    Save
                  </button>
                  <button className="px-3 py-2 border rounded-lg" onClick={() => setEditing(undefined)}>
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <>
                <div className="font-medium">{a.title}</div>
                <div className="text-sm text-slate-600">
                  Owner: {a.ownerName || "Unassigned"} • Due: {fmtDate(a.dueDate)}
                </div>
                <div className="flex flex-wrap gap-2 pt-2">
                  <button
                    className="px-3 py-1.5 bg-brand text-white rounded-lg"
                    onClick={() => approve(a.id)}
                  >
                    Approve
                  </button>
                  <button
                    className="px-3 py-1.5 bg-red-600 text-white rounded-lg"
                    onClick={() => reject(a.id)}
                  >
                    Reject
                  </button>
                  <button
                    className="px-3 py-1.5 border rounded-lg"
                    onClick={() => startEdit(a.id)}
                  >
                    Amend
                  </button>
                  <button
                    className="px-3 py-1.5 border rounded-lg text-red-600"
                    onClick={() => handleDelete(a.id)}
                  >
                    Delete
                  </button>
                </div>
              </>
            )}
          </div>
        ))}
        {!pendingItems.length && (
          <div className="text-sm text-slate-600">No pending actions 🎉</div>
        )}
      </div>

      {/* History */}
      <h2 className="font-semibold text-slate-800">History</h2>
      <div className="grid lg:grid-cols-2 gap-4">
        {historyItems.map(a => (
          <div key={a.id} className="bg-slate-50 border rounded-2xl shadow p-4">
            <div className="font-medium">{a.title}</div>
            <div className="text-sm">
              Status:{" "}
              <span className={a.status === "accepted" ? "text-green-600" : "text-red-600"}>
                {a.status}
              </span>
            </div>
          </div>
        ))}
        {!historyItems.length && (
          <div className="text-sm text-slate-600">No past actions yet</div>
        )}
      </div>
    </div>
  )
}
