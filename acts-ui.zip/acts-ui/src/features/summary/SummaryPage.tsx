import HeroBanner from "@/components/common/HeroBanner"
import hero from "@/assets/hero-bg.svg"
import { useActsStore } from "@/store/useActsStore"
import { useEffect, useMemo, useState } from "react"

export default function SummaryPage() {
  const { actions, loadAll } = useActsStore()
  useEffect(() => { loadAll() }, [])

  const groups = useMemo(() => ({
    Decisions: [
      { id: "d1", title: "Move ahead with Q3 roadmap sign-off" },
      { id: "d2", title: "Adopt new review workflow" },
    ],
    "Action Items": actions.length
      ? actions
          .filter(a => a.type === "Action")
          .map(a => ({
            id: a.id,
            title: a.title,
            ownerName: a.ownerName,
          }))
      : [],
    FYIs: [
      { id: "f1", title: "Next sprint starts on Monday" },
      { id: "f2", title: "Security review scheduled for 15th" },
    ],
    "Open Questions": [
      { id: "q1", title: "Do we have budget for additional licenses?" },
      { id: "q2", title: "Should we shift timeline for release X?" },
    ],
  }), [actions])

  const tabs = Object.keys(groups)
  const [active, setActive] = useState("Decisions")

  return (
    <div className="space-y-6">
      <HeroBanner
        title="AI-Generated Summary"
        subtitle="A gist of key decisions, action items, FYIs and open questions"
        bgImage={hero}
      />

      {/* Tabs */}
      <div className="flex gap-2">
        {tabs.map(t => (
          <button
            key={t}
            onClick={() => setActive(t)}
            className={`px-4 py-2 rounded-lg text-sm font-medium border transition
              ${active === t
                ? "bg-brand text-white border-brand"
                : "bg-white text-slate-700 hover:bg-slate-50 border-slate-200"}`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Cards */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {groups[active].map(it => (
          <div key={it.id} className="bg-white border rounded-2xl shadow-card p-5">
            <div className="font-semibold">{it.title}</div>
            {it.ownerName && (
              <div className="text-sm text-slate-600 mt-1">Owner: {it.ownerName}</div>
            )}
          </div>
        ))}
        {!groups[active].length && (
          <div className="text-sm text-slate-600">No {active.toLowerCase()} yet</div>
        )}
      </div>
    </div>
  )
}
