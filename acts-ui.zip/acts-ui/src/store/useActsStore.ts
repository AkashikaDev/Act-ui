import { create } from "zustand"
import { ActionItem, User, fetchActions, fetchUsers, updateAction, addActionApi } from "@/lib/fakeApi"

interface ActsState {
actions: ActionItem[]
users: User[]
loadAll: () => Promise<void>
  setAction: (a: ActionItem) => Promise<void>
  addAction: (a: ActionItem) => Promise<void>
  deleteAction: (id: string) => Promise<void>
}

export const useActsStore = create<ActsState>((set) => ({
  actions: [],
  users: [],
  loadAll: async () => {
    const [actions, users] = await Promise.all([fetchActions(), fetchUsers()])
    set({ actions, users })
  },
  setAction: async (a: ActionItem) => {
    await updateAction(a)
    set(state => ({
      actions: state.actions.map(x => x.id === a.id ? { ...x, ...a } : x)
    }))
  },
  addAction: async (a: ActionItem) => {
    await addActionApi(a)
    set(state => ({
      actions: [...state.actions, a]
    }))
  },
  deleteAction: async (id: string) => {
    set(state => ({
      actions: state.actions.filter(a => a.id !== id)
    }))
  }
}))
