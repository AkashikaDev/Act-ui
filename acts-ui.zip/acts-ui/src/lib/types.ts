export type ActionStatus = 'pending' | 'accepted' | 'rejected' | 'done'

export interface User {
    id: string
    name: string
    email?: string
role?: 'Host' | 'Panelist' | 'Scribe' | 'Participant'
}

export interface Meeting {
id: string
title: string
date: string
transcriptUrl?: string
}

export interface ActionItem {
id: string
meetingId: string
title: string
ownerId?: string
ownerName?: string
dueDate?: string
status: ActionStatus
type?: 'Decision' | 'Action' | 'FYI' | 'Question'
notes?: string
}
