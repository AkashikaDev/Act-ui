// Types
export interface ActionItem {
    id: string
    title: string
    type: "Decision" | "Action" | "FYI" | "Question"
ownerId?: string
ownerName?: string
status: "pending" | "accepted" | "rejected" | "done"
dueDate?: string
}

export interface User {
id: string
name: string
}

// --- Mock Users ---
export const mockUsers: User[] = [
{ id: "u1", name: "Kristin Watson" },
{ id: "u2", name: "Wade Warren" },
{ id: "u3", name: "Jordan Ops" },   // “logged in” user
{ id: "u4", name: "Jenny Wilson" },
]

// --- Mock Actions ---
export const mockActions: ActionItem[] = [
{
id: "a1",
title: "Prepare rollback plan for gateway v2",
type: "Action",
ownerId: "u3",
ownerName: "Jordan Ops",
status: "pending"
},
{
id: "a2",
title: "Review design mockups",
type: "Action",
ownerId: "u1",
ownerName: "Kristin Watson",
status: "pending"
},
{
id: "a3",
title: "Check with vendor about pricing",
type: "Action",
ownerId: "u2",
ownerName: "Wade Warren",
status: "accepted"
},
{
id: "a4",
title: "Finalize presentation",
type: "Action",
ownerId: "u4",
ownerName: "Jenny Wilson",
status: "rejected"
}
]

// --- Mock fetch/update ---
export async function fetchActions(): Promise<ActionItem[]> {
  return Promise.resolve(mockActions)
}

export async function fetchUsers(): Promise<User[]> {
  return Promise.resolve(mockUsers)
}

export async function updateAction(updated: ActionItem): Promise<ActionItem> {
  const idx = mockActions.findIndex(a => a.id === updated.id)
  if (idx !== -1) {
    mockActions[idx] = { ...mockActions[idx], ...updated }
  }
  return Promise.resolve(updated)
}

export async function addActionApi(newAction: ActionItem): Promise<ActionItem> {
  mockActions.push(newAction)   // 👈 persist in dataset
  return Promise.resolve(newAction)
}
