import { format, isValid, parseISO } from 'date-fns'
export function fmtDate(d?: string) {
  if (!d) return '—'
  const date = parseISO(d)
  return isValid(date) ? format(date, 'dd MMM yyyy') : '—'
}
