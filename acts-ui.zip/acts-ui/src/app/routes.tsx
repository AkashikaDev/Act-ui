import { createBrowserRouter } from "react-router-dom"
import App from "./App"
import SummaryPage from "@/features/summary/SummaryPage"
import ReviewPage from "@/features/review/ReviewPage"
import AssignPage from "@/features/assign/AssignPage"
import TasksPage from "@/features/tasks/TasksPage"
import FollowupsPage from "@/features/followups/FollowupsPage"
import DashboardPage from "@/features/dashboard/DashboardPage"

export const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      { index: true, element: <SummaryPage /> },
      { path: "review", element: <ReviewPage /> },
      { path: "assign", element: <AssignPage /> },
      { path: "tasks", element: <TasksPage /> },
      { path: "followups", element: <FollowupsPage /> },
      { path: "dashboard", element: <DashboardPage /> },
    ]
  }
])
