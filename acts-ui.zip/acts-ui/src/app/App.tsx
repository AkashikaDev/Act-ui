import { Outlet, NavLink } from "react-router-dom"
import att from "@/assets/att-hack-logo.svg"

export default function App() {
  return (
    <div className="flex min-h-screen bg-slate-50">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r shadow-sm flex flex-col">
        <div className="h-20 flex items-center justify-center border-b">
          <img src={att} alt="EquiTech’25" className="h-12 w-auto" />
        </div>
        <nav className="flex-1 p-4 space-y-2 text-slate-700">
          <NavLink to="/" end className={({ isActive }) =>
            `block px-3 py-2 rounded-lg hover:bg-slate-100 ${isActive ? "bg-brand text-white" : ""}`}>
            Summary
          </NavLink>
          <NavLink to="/review" className={({ isActive }) =>
            `block px-3 py-2 rounded-lg hover:bg-slate-100 ${isActive ? "bg-brand text-white" : ""}`}>
            Review
          </NavLink>
          <NavLink to="/assign" className={({ isActive }) =>
            `block px-3 py-2 rounded-lg hover:bg-slate-100 ${isActive ? "bg-brand text-white" : ""}`}>
            Assign
          </NavLink>
          <NavLink to="/tasks" className={({ isActive }) =>
            `block px-3 py-2 rounded-lg hover:bg-slate-100 ${isActive ? "bg-brand text-white" : ""}`}>
            Tasks
          </NavLink>
          <NavLink to="/followups" className={({ isActive }) =>
            `block px-3 py-2 rounded-lg hover:bg-slate-100 ${isActive ? "bg-brand text-white" : ""}`}>
            Follow-ups
          </NavLink>
          <NavLink to="/dashboard" className={({ isActive }) =>
            `block px-3 py-2 rounded-lg hover:bg-slate-100 ${isActive ? "bg-brand text-white" : ""}`}>
            Dashboard
          </NavLink>
        </nav>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col">
        {/* Broader header */}
        <header className="h-20 bg-white border-b flex items-center justify-between px-6 shadow-sm">
          <h1 className="text-xl font-extrabold text-ink">AI Meeting Action Tracker</h1>
          <div className="w-10 h-10 rounded-full bg-slate-200" />
        </header>

        <main className="flex-1 p-6 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
