/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ["class"],
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: "#146EF5",   // primary blue
        accent: "#00C2FF",  // cyan accent
        ink: "#0F172A"      // deep text
      },
      boxShadow: {
        card: "0 6px 24px rgba(2, 8, 23, 0.06)"
      },
      borderRadius: {
        '2xl': '1rem'
      }
    },
  },
  plugins: [],
}
